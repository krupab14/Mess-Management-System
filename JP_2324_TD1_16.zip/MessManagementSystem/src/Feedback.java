import javax.swing.*;
import javax.swing.border.LineBorder;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Feedback extends JFrame implements ActionListener {
    JButton submitbtn, homeBtn;
    JLabel feedbackLbl;
    JTextArea feedbackTextArea;
    JLabel usrLabel;
    JTextField usrTxf;

    Feedback() {
        setSize(500, 500);
        setTitle("Feedback");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null); // Set layout to null for absolute positioning

        feedbackLbl = new JLabel("Enter Feedback:");
        feedbackLbl.setBounds(50, 50, 150, 30); // Adjusted bounds
        add(feedbackLbl);

        feedbackTextArea = new JTextArea();
        feedbackTextArea.setBounds(50, 90, 400, 200); // Adjusted bounds for better visibility
        feedbackTextArea.setBorder(new LineBorder(Color.BLACK)); 
        add(feedbackTextArea);

        usrLabel = new JLabel("Enter username:");
        usrLabel.setBounds(100, 300, 100, 30);
        add(usrLabel);

        usrTxf = new JTextField();
        usrTxf.setBounds(260, 300, 150, 30);
        add(usrTxf);

        submitbtn = new JButton("Submit");
        submitbtn.setBounds(200, 345, 100, 30); // Adjusted bounds
        add(submitbtn);
        submitbtn.addActionListener(this); // Register action listener

        homeBtn = new JButton("Home");
        homeBtn.setBounds(200, 385, 100, 30);
        add(homeBtn);
        homeBtn.addActionListener(this); // Register action listener

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == submitbtn) {
            insertFeedback(); // Call method to insert feedback when Submit button is clicked
        } else if (e.getSource() == homeBtn) {
            setVisible(false);
            HomePage homeFrame = new HomePage();
            homeFrame.setVisible(true);
        }
    }

    private void insertFeedback() {
        // Retrieve username and feedback from text fields
        String username = usrTxf.getText().trim();
        String feedback = feedbackTextArea.getText().trim();

        // Validate if username or feedback is empty
        if (username.isEmpty() || feedback.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter both username and feedback.");
            return;
        }

        // Database connection variables
        String url = "jdbc:mysql://localhost:3306/mess";
        String user = "root";
        String password = "";

        // SQL query to insert feedback into Feedback table
        String sql = "INSERT INTO Feedback (username, feedback) VALUES (?, ?)";

        try (Connection connection = DriverManager.getConnection(url, user, password);
             PreparedStatement statement = connection.prepareStatement(sql)) {

            // Set parameters for the SQL query
            statement.setString(1, username);
            statement.setString(2, feedback);

            // Execute the SQL query
            int rowsInserted = statement.executeUpdate();

            // Check if the insertion was successful
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(this, "Feedback submitted successfully.");
            } else {
                JOptionPane.showMessageDialog(this, "Failed to submit feedback.");
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Failed to submit feedback: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        new Feedback();
    }
}
