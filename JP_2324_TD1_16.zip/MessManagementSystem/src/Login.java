import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Login extends JFrame implements ActionListener {
 JButton submitBtn;
    JLabel usrLbl, pwdLbl,authenticateLbl;
    JTextField usrTxf, pwdTxf;

    public Login(){
        setVisible(true);
        setSize(500,500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setTitle("Login");

        usrLbl = new JLabel("Enter Username:");
        usrLbl.setBounds(30,100,150,30);
        pwdLbl = new JLabel("Enter Password:");
        pwdLbl.setBounds(30,150,150,30);
        authenticateLbl = new JLabel();
        authenticateLbl.setBounds(140, 250, 150, 30);
        add(usrLbl);
        add(pwdLbl);
        add(authenticateLbl);

        usrTxf = new JTextField();
        usrTxf.setBounds(200,100,150,30);
        pwdTxf = new JTextField();
        pwdTxf.setBounds(200,150,150,30);
        add(usrTxf);
        add(pwdTxf);


        submitBtn = new JButton("Submit");
        submitBtn.setBounds(120,200,150,30);
        add(submitBtn);
        submitBtn.addActionListener(this);
    }

    public void actionPerformed(ActionEvent ae){
        if (ae.getSource() == submitBtn) {
            authenticate();
        }
    }

    public void authenticate(){
        String usrData = usrTxf.getText();
        String pwdData = pwdTxf.getText();
        String url = "jdbc:mysql://localhost:3306/mess";
        String user = "root";
        String dbPassword = "";

        try (Connection connection = DriverManager.getConnection(url, user, dbPassword)) {
            String query = "SELECT * FROM register WHERE username = ? AND password = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, usrData);
            statement.setString(2, pwdData);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                setVisible(false);
                HomePage homePageFrame = new HomePage();
                homePageFrame.setVisible(true);
            } else {
                authenticateLbl.setText("Invalid credentials!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new Login();
    }
}
