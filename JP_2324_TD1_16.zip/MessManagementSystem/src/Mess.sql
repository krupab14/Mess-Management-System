CREATE TABLE Register (
    username VARCHAR(50),
    password VARCHAR(50),
    email VARCHAR(100),
    gr INT
);


CREATE TABLE menu (
    day_of_week ENUM('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday') NOT NULL,
    breakfast VARCHAR(255) NOT NULL,
    lunch VARCHAR(255) NOT NULL,
    snacks VARCHAR(255) NOT NULL,
    dinner VARCHAR(255) NOT NULL,
    PRIMARY KEY (day_of_week)
);

INSERT INTO menu (day_of_week, breakfast, lunch, snacks, dinner)
VALUES
    ('Monday', 'Upma', 'Chana Masala with Roti', 'Samosa', 'Paneer Tikka Masala'),
    ('Tuesday', 'Poha', 'Dal Makhani with Rice', 'Bhel Puri', 'Aloo Gobi'),
    ('Wednesday', 'Idli with Sambar', 'Palak Paneer with Naan', 'Pakora', 'Vegetable Biryani'),
    ('Thursday', 'Masala Dosa', 'Rajma with Chapati', 'Paneer Pakora', 'Vegetable Curry'),
    ('Friday', 'Paratha with Curd', 'Baingan Bharta with Roti', 'Aloo Tikki', 'Chole Bhature'),
    ('Saturday', 'Poori Bhaji', 'Matar Paneer with Rice', 'Vada Pav', 'Paneer Butter Masala'),
    ('Sunday', 'Dhokla', 'Vegetable Pulao', 'Chaat', 'Paneer Bhurji');

    CREATE TABLE Attendance (
    attendance_id INT AUTO_INCREMENT PRIMARY KEY,
    date DATE NOT NULL,
    student_id INT NOT NULL,
    present BOOLEAN NOT NULL
);

CREATE TABLE Feedback (
    feedback_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50),
    feedback TEXT
);

