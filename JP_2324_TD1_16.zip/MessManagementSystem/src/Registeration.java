import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Registeration extends JFrame implements ActionListener{
    JButton submitBtn, loginBtn;
    JLabel usrLbl, pwdLbl, mailLbl, grLbl;
    JTextField usrTxf, pwdTxf, mailTxf, grTxf;

    Connection con;
    Statement stmt;
    ResultSet rs;
    PreparedStatement ps;

    String usrData, pwdData, mailData, grData;
    

    public Registeration(){
        setVisible(true);
        setSize(500,500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setTitle("Registeration");

        usrLbl = new JLabel("Enter Username:");
        usrLbl.setBounds(30,100,150,30);
        pwdLbl = new JLabel("Enter Password:");
        pwdLbl.setBounds(30,150,150,30);
        mailLbl = new JLabel("Enter Email");
        mailLbl.setBounds(30,200,150,30);
        grLbl = new JLabel("Enter GR number:");
        grLbl.setBounds(30,250,150,30);
        add(usrLbl);
        add(pwdLbl);
        add(mailLbl);
        add(grLbl);

        usrTxf = new JTextField();
        usrTxf.setBounds(200,100,150,30);
        pwdTxf = new JTextField();
        pwdTxf.setBounds(200,150,150,30);
        mailTxf = new JTextField();
        mailTxf.setBounds(200,200,150,30);
        grTxf = new JTextField();
        grTxf.setBounds(200,250,150,30);
        add(usrTxf);
        add(pwdTxf);
        add(mailTxf);
        add(grTxf);

        submitBtn = new JButton("Submit");
        submitBtn.setBounds(120,300,150,30);
        submitBtn.addActionListener(this);
        loginBtn = new JButton("Login");
        loginBtn.setBounds(120,350,150,30);
        loginBtn.addActionListener((ActionListener) this);
        add(submitBtn);
        add(loginBtn);

    }

    public void insertData(){
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mess", "root","");
            usrData = usrTxf.getText().toString();
            pwdData = pwdTxf.getText().toString();
            mailData = mailTxf.getText().toString();
            grData = grTxf.getText().toString();

            String sqlQuery = "INSERT INTO register  (username, password, email, gr) VALUES ('" + usrData + "', '" + pwdData + "', '" + mailData + "', '" + grData + "')";

            ps = con.prepareStatement(sqlQuery);

            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this,"Data inserted successfully");
                setVisible(false);
                Login loginframe = new Login();
                loginframe.setVisible(true);
                
            }
            else{
                JOptionPane.showMessageDialog(this,"Data failed to insert");
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        finally {
            try {
                // Closing the resources
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == loginBtn) {
            // Hide the registration frame
            setVisible(false);
            
            // Create and display the login frame
            Login loginFrame = new Login();
            loginFrame.setVisible(true);
        }
        if (e.getSource() == submitBtn) {
            insertData();
        }

    }

    public static void main(String[] args) throws ClassNotFoundException {
        new Registeration();
    }
}
    

