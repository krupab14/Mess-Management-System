import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.awt.event.ActionListener;

public class Menu extends JFrame implements ActionListener {
    private JComboBox<String> weekdayComboBox;
    private JTextArea resultArea;
    private JButton homeBtn;
    private JPanel menuPanel;

    public Menu() {
        setTitle("Menu");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(500, 500);
        setLayout(null);

        JLabel titleLabel = new JLabel("Select a weekday to see menu:");
        titleLabel.setBounds(140, 50, 200, 30);
        add(titleLabel);

        homeBtn = new JButton("Home");
        homeBtn.setBounds(150, 400, 150, 30);
        homeBtn.addActionListener(this);
        add(homeBtn);

        // Initialize the JComboBox with the array of weekdays
        String[] weekdays = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
        weekdayComboBox = new JComboBox<>(weekdays);
        weekdayComboBox.setBounds(150, 100, 150, 30);
        // Automatically select the current weekday
        weekdayComboBox.setSelectedIndex(LocalDate.now().getDayOfWeek().getValue() - 1);
        // Add action listener to the combo box
        weekdayComboBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                displayMenu();
            }
        });
        add(weekdayComboBox);

        // Initialize the result area
        resultArea = new JTextArea();
        resultArea.setBounds(50, 150, 400, 200);
        resultArea.setEditable(false);
        add(resultArea);

        displayMenu(); // Display menu for the current day initially

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == homeBtn) {
            setVisible(false);
            HomePage homeFrame = new HomePage();
            homeFrame.setVisible(true);
            // Go to the home page or perform other actions here
        }
    }

    // Display the menu based on the selected weekday
    private void displayMenu() {
        String selectedWeekday = (String) weekdayComboBox.getSelectedItem();
        String menu = getMenuFromDatabase(selectedWeekday);
        resultArea.setText(menu);
    }

    // Retrieve menu from the database based on the selected weekday
    private String getMenuFromDatabase(String weekday) {
        String menu = "";
        try {
            //Class.forName("com.mysql.cj.jdbc.Driver");
            // Establish database connection
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mess", "root", "");
            // Prepare SQL statement
            String query = "SELECT * FROM menu WHERE day_of_week = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, weekday);
            // Execute query
            ResultSet resultSet = statement.executeQuery();
            // Process result set
            if (resultSet.next()) {
                // Retrieve menu items
                String breakfast = resultSet.getString("breakfast");
                String lunch = resultSet.getString("lunch");
                String snacks = resultSet.getString("snacks");
                String dinner = resultSet.getString("dinner");
                // Build menu string
                menu += "Breakfast: " + breakfast + "\n";
                menu += "Lunch: " + lunch + "\n";
                menu += "Snacks: " + snacks + "\n";
                menu += "Dinner: " + dinner;
            } else {
                menu = "Menu not available for " + weekday;
            }
            // Close connection
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
            menu = "Error retrieving menu";
        }
        return menu;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Menu();
            }
        });
    }
}
