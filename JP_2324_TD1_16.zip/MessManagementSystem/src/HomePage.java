import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JFrame;

public class HomePage extends JFrame implements ActionListener
{
    JButton showMenuPageBtn, attendencePageBtn, feedbackPageBtn ;
    public HomePage()
    {
        setSize(500,500);
        setTitle("HomePage");
        setVisible(true);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        showMenuPageBtn = new JButton("Menu");
        showMenuPageBtn.setBounds(150,150,150,30);
        attendencePageBtn = new JButton("Attendence");
        attendencePageBtn.setBounds(150,200,150,30);
        feedbackPageBtn = new JButton("Feedback");
        feedbackPageBtn.setBounds(150,250,150,30);
        add(showMenuPageBtn);
        add(attendencePageBtn);
        add(feedbackPageBtn);
        showMenuPageBtn.addActionListener(this);
        attendencePageBtn.addActionListener(this);
        feedbackPageBtn.addActionListener((ActionListener) this);
    }


    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == showMenuPageBtn) {
            // Hide the registration frame
            setVisible(false);
            
            // Create and display the login frame
            Menu menuframe = new Menu();
            menuframe.setVisible(true);
        }
        if(e.getSource() == attendencePageBtn){
            setVisible(false);
            Attendance attendenceframe = new Attendance();
            attendenceframe.setVisible(true);
        }
        if (e.getSource() == feedbackPageBtn) {
            setVisible(false);
            Feedback feedbackFrame = new Feedback();
            feedbackFrame.setVisible(true);
        }
    }


    public static void main(String[] args) {
        HomePage demo = new HomePage();
    }
}