import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class Attendance extends JFrame {

    private DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
    private JButton submitButton, homeBtn;
    JLabel usrLabel;
    JTextField usrTxf;
    private int checkBoxY = 40;

    public Attendance() {
        setTitle("Attendance");
        setSize(500, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);

        JButton showButton = new JButton("Show Week");
        showButton.setBounds(200, 10, 100, 20);
        showButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Date startDate = new Date(); // Get current date
                displayWeekCheckBoxes(startDate);
            }
        });
        add(showButton);

        usrLabel = new JLabel("Enter username:");
        usrLabel.setBounds(100,280,100,30);
        add(usrLabel);
        usrTxf = new JTextField();
        usrTxf.setBounds(260,280,150,30);
        add(usrTxf);


        submitButton = new JButton("Submit Attendance");
        submitButton.setBounds(180, 320, 150, 30);
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                markAttendance();
                setVisible(false);
                HomePage homeFrame = new HomePage();
                homeFrame.setVisible(true);
            }
        });

        setVisible(true);

        homeBtn = new JButton("Home");
        homeBtn.setBounds(180, 360, 150, 30);
        homeBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                setVisible(false);
                HomePage homeFrame = new HomePage();
                homeFrame.setVisible(true);
            }
        });
    }

    private void displayWeekCheckBoxes(Date startDate) {
    
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(startDate);

        for (int i = 0; i < 7; i++) {
            JCheckBox checkBox = new JCheckBox(dateFormat.format(calendar.getTime()));
            checkBox.setBounds(40, checkBoxY, 150, 20);
            getContentPane().add(checkBox);
            calendar.add(Calendar.DAY_OF_MONTH, 1); // Move to the next day
            checkBoxY += 30; // Increase y-coordinate for the next checkbox
        }

        // Reset y-coordinate for the submit button
        checkBoxY = 40;

        // Add the submit button again
        add(submitButton);
        add(homeBtn);

        revalidate();
        repaint();
    }

    private void markAttendance() {
        // Get the username from the text field
        String username = usrTxf.getText().trim();
    
        if (username.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a username.");
            return;
        }
    
        // Connect to the database
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mess", "root", "")) {
            // Prepare SQL statement for insertion
            String query = "INSERT INTO Attendance (date, username, present) VALUES (?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
    
            // Get the selected checkboxes and mark attendance for each
            Component[] components = getContentPane().getComponents();
            for (Component component : components) {
                if (component instanceof JCheckBox) {
                    JCheckBox checkBox = (JCheckBox) component;
                    Date date = null;
                    try {
                        date = dateFormat.parse(checkBox.getText());
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                    int present = checkBox.isSelected() ? 1 : 0;
    
                    // Insert attendance record into the database
                    statement.setDate(1, new java.sql.Date(date.getTime()));
                    statement.setString(2, username); // Use retrieved username
                    statement.setInt(3, present);
                    statement.executeUpdate();
                }
            }
            JOptionPane.showMessageDialog(this, "Attendance marked successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Failed to mark attendance.");
        }
    }
    

    public static void main(String[] args) {
        new Attendance();
    }
}
